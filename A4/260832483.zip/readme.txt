I didn't quite follow the provided source code of quicksort, so there might be some minor differences about how I handled the list. 
For the quicksort part, I used some of the code I found on the Internet because this assignment was taking much longer than I expected. 
Here is the website:
https://github.com/hakjong/mips-qsort/blob/master/quick.s